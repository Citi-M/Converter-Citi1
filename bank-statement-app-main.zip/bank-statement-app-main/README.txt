ИНСТРУКЦИЯ ДЛЯ macOS

1. Откройте Terminal
2. Перейдите в папку с проектом:
   cd путь_к_папке/bank-statement-app

3. Установите зависимости:
   pip3 install -r requirements.txt

4. Запустите приложение:
   streamlit run app.py

Откроется браузер с адресом http://localhost:8501
